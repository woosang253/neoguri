package jp.devfox.jungle.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;

public class GsonRenkei {  
	
	public Object getResult() throws MalformedURLException, IOException {
		return readApi();
	}
	
	private String readApi() throws MalformedURLException, IOException {
		
		/*
		String apiKey = (String) Common.getControlValue(Common.API_KEY);
		String apiUrl = (String) Common.getControlValue(Common.API_URL);
		*/
		String apiKey = "DeoaANXzkS7dmkuJLkawgGAnbRBBDQm3";
		String apiUrl = "https://www.koreaexim.go.kr/site/program/financial/exchangeJSON?data=AP01&authkey=";
		
		StringBuilder sb = new StringBuilder(apiUrl);
		sb.append(apiKey);
		
		if(isWeekend()) {
			sb.append("searchdate=");
		}
		
		String resultApiAddress = sb.toString();
		
		InputStream is = new URL(resultApiAddress).openStream();
		BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
		
		StringBuilder resultJsonText = new StringBuilder();
	    int cp;
	    while ((cp = rd.read()) != -1) {
	    	resultJsonText.append((char) cp);
	    }

		return resultJsonText.toString();
	}
	
	private Boolean isWeekend() {
		
		return false;
	}
}
