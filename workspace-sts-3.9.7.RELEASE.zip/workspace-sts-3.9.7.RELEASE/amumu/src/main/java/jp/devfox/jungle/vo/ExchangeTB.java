package jp.devfox.jungle.vo;

import java.math.BigDecimal;
import java.sql.Date;

public class ExchangeTB {

	private String inExchange;
	private String outExchange;
	private Date gettedTime;
	private BigDecimal rate;

	public String getInExchange() {
		return inExchange;
	}
	public void setInExchange(String inExchange) {
		this.inExchange = inExchange;
	}
	public String getOutExchange() {
		return outExchange;
	}
	public void setOutExchange(String outExchange) {
		this.outExchange = outExchange;
	}
	public Date getGettedTime() {
		return gettedTime;
	}
	public void setGettedTime(Date gettedTime) {
		this.gettedTime = gettedTime;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
}
