package jp.devfox.jungle.util;

public class CommonString {
	
	public static String getValue(String getData) {
		return (getData == null) ? "" : getData;
	}

	public static String shori(String... aa) {
		StringBuilder sb = new StringBuilder();
		
		for(int i=0;i<aa.length;i++) {
			sb.append(aa[i]);
			if(i!=aa.length-1) {
				sb.append(",");
			}
		}
		return sb.toString();
	}
}
