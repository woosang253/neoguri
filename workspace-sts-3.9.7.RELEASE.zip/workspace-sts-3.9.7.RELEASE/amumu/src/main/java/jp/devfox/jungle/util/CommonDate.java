package jp.devfox.jungle.util;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

public class CommonDate {

	public static Date countyCode() throws SQLException {

		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();

		Boolean holiday = Common.getHoliday(date, "je_jp");

		// date, country -
		// Common.getHoliday("ko_kr");
		// Common.getHoliday(date, countryCode)
		// 모든 날짜와, 국가코드를 가져와서,
		// db에 데이터가 존재할 경우 국가공휴일이므로
		// false를 return하고, true이면, 아래쪽 판단을 진행하도록 한다.
		// 월요일 공휴일 경우, 전주의 금요일을 가져오는데, 그 금요일도 휴일인지 판단해서
		// 날짜를 반환

		// 공휴일 체크
		if (holiday == true) {
			// 현재 날짜가 월요일이면
			if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {

				cal.add(Calendar.DATE, cal.get((Calendar.DAY_OF_WEEK) - 3));

				// 금요일 변수
				Boolean holickFriday = Common.getHoliday(cal.getTime(), "je_jp");

				// 전주 금요일로 가져옴.
				if (holickFriday == true) { // 의문1. 파라미터를 넘겨야 하지 않나요.
					return getWeekDay();
				}
			}
		} else if (holiday == false) {
			return getWeekDay();
		} else {
			return getWeekDay();           // 의문2. 가각에 해당하는 날짜와 휴일체크가 다르므로, 매개변수 파라미터를 메소드를 불러오면서 파라미터를 넘겨야 하는게 아닌가 싶습니다.
		}                                  // 의문3. 맨 처음 불러내는 메소드가 countyCode()가 되어야 할 것같다는 생각을 해봤습니다. 
		return getWeekDay();

	}

	public static Date setZeroTime() {
		// 현재 날짜 설정
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		return cal.getTime();
	}

	public static boolean isWeekend() {
		// 현재 날짜 설정
		Calendar cal = Calendar.getInstance();
		setZeroTime();
		// 주말체크 예를 들면 Calendar.WEDNESDAY로 오늘 요일로 바꿔야만 출력 시험할 수 있습니다. 아래에도 있습니다.
		if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			// 가져온 현재 요일의 상수 == 토요일의 상수 || 가져온 현재 요일의 상수 == 금요일의 상수
			return true;
		} else {
			return false;
		}
	}

	public static Date getWeekDay() {
		// 현재 날짜 설정
		Calendar cal = Calendar.getInstance();
		setZeroTime();
		// 주말체크 예를 들면 Calendar.WEDNESDAY로 오늘 요일로 바꿔야만 출력 시험할 수 있습니다. 아래에도 있습니다.
		if (isWeekend() == true) {
			cal.add(Calendar.DATE, cal.get((Calendar.DAY_OF_WEEK) - Calendar.FRIDAY) * -1);
		}
		return cal.getTime();
	}

	public static String changeToDate(Date date) {
		return String.valueOf(date);
		// 심플데이트 포멧이라는 것으로 데이터 형태를 바꿔주어야함
	}
}