/**
 * 各種、テストを実施するため、テストコントローラーです。
 * マーピングは /~~Test.doで名前をつけってください。
 * 
 * @author LEE_KS
 */

package jp.devfox.jungle.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;

import jp.devfox.jungle.util.GsonRenkei;

@Controller
public class TestController {
	
	private static final Logger logger = LoggerFactory.getLogger(TestController.class);
	@Autowired DataSource dataSource;
	
	/**
	 * DBの接続を確認します。
	 * @param model
	 * @return
	 */
	@RequestMapping("/dbTest.do")
    public String dbTest(Model model) {
        Connection conn = null;
        Statement st = null;
        
        try {
        	conn = dataSource.getConnection();
            st = conn.createStatement();
            ResultSet rs = st.executeQuery("select now() as now;");
            
            while(rs.next()) {
                model.addAttribute("serverTime", rs.getString("now"));
            }
            
        } catch (Exception e) {
            e.printStackTrace();    
            
        } finally {
            try {
                if(st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
            try {
                if(conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }                        
        }
        
        return "home";
    }
	
	@RequestMapping("/gsonTest.do")
	public String gsonTest(Model model) throws MalformedURLException, IOException {
		GsonRenkei gsonRenkei = new GsonRenkei();
		logger.info("result {}",gsonRenkei.getResult());
		
		return "gson_test";
	}
}
