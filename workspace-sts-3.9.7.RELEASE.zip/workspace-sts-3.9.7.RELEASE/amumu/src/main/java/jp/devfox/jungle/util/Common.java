﻿package jp.devfox.jungle.util;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;

public class Common {
	private final static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; // 드라이버
	private final static String DB_URL = "jdbc:mysql://35.224.153.13/devfox?&useSSL=false"; // 접속할 DB 서버//대애충 서버쓰기

	private final static String USER_NAME = "sakurai"; // DB에 접속할 사용자 이름을 상수로 정의
	private final static String PASSWORD = "sho82"; // 사용자의 비밀번호를 상수로 정의

	public final static String API_KEY = "";
	public final static String API_URL = "";

	public static Object getControlValue(String key) {

		return null;
	}

	public static Object getControlValue(String key, String value1) {

		return null;
	}

	public static String addString(List<String> list) {
		String te = "";
		for (int i = 0; i < list.size(); i++) {
			te = te + list.get(i);

		}
		return te;
	}

	public static String addStringDESE(List<String> list) {
		String te = "";
		for (int i = list.size(); i > 0; i--) {
			te = te + list.get(i - 1);

		}
		return te;
	}

	public static Boolean getHoliday(Date date, String countryCode) throws SQLException {
		Connection conn = null;
		Statement state = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
			state = conn.createStatement();

			String sql; // SQL문을 저장할 String
			sql = "SELECT * FROM Holiday_MST_TB WHERE date = " + CommonDate.changeToDate(date) + " AND countryCode = "
					+ countryCode;
			rs = state.executeQuery(sql); // SQL문을 전달하여 실행

			if (rs.next()) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}

		} catch (Exception e) {
			// 예외 발생 시 처리부분

		} finally { // 예외가 있든 없든 무조건 실행
			if (rs != null) {
				rs.close();
			}
			if (state != null) {
				state.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

		return Boolean.FALSE;
	}

	public static Boolean addExchangeData(String inExchange, String outExchange, Date gettedTime, BigDecimal rate) throws SQLException {
		Connection conn = null;
		Statement state = null;
		ResultSet rs = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
			state = conn.createStatement();

			
			
			String sql; // SQL문을 저장할 String
			sql = "INSERT INTO FROM EXCHANGE_TB(inExchange,outExchange,gettedTime,rate)"
					+ " VALUES=("+CommonString.shori(inExchange,outExchange,gettedTime.toString(),rate.toPlainString())+")";
			rs = state.executeQuery(sql); // SQL문을 전달하여 실행

			if (rs.next()) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}

		} catch (Exception e) {
			// 예외 발생 시 처리부분

		} finally { // 예외가 있든 없든 무조건 실행
			if (rs != null) {
				rs.close();
			}
			if (state != null) {
				state.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

		return Boolean.FALSE;
	}
}
