﻿package jp.devfox.jungle;

import java.util.ArrayList;
import java.util.List;

import jp.devfox.jungle.util.Common;

public class CommonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list = new ArrayList<String>();
		/*형식알아두자
		 * List는 넣는방법이 따로 있다*/ 
		list.add("마츠준1");
		list.add("사쿠쇼2");
		list.add("밧쨩3");
		list.add("니노4");
		list.add("리다5");
				//이름변경은 리팩터 
		//class나 변수명변경도 가능 
		//Common.addStringDESE(list);
		

		/*public static Object addString(List<String> list) {
		*　를 입력하면 Object형으로 반환되었으나 Common.java에서
		*　public static String addString(List<String> list) { 
		*　로 바꿔주워 return되는 형식이 변경되었다 */ 

		System.out.println(Common.addString(list));
		System.out.println(Common.addStringDESE(list));
		//부를때는 요렇게 다시 공부하자 성은아 !

		System.out.println(Common.addStringDESE(list));
	}

}
