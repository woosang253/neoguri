package jp.devfox.jungle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jp.devfox.jungle.util.Common;
import jp.devfox.jungle.util.CommonDate;

public class MySQLConnectTest {
	private final static String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; // 드라이버
	private final static String DB_URL = "jdbc:mysql://35.224.153.13/devfox?&useSSL=false"; // 접속할 DB 서버//대애충 서버쓰기
	

	private final static String USER_NAME = "sakurai"; // DB에 접속할 사용자 이름을 상수로 정의
	private final static String PASSWORD = "sho82"; // 사용자의 비밀번호를 상수로 정의

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		//run();
		Common.getHoliday(CommonDate.setZeroTime() , "ko_kr");
		System.out.println(Common.getHoliday(CommonDate.setZeroTime() , "ko_kr"));
	}

	// 생성자
	public static void run() {
		Connection conn = null;
		Statement state = null;
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
			state = conn.createStatement();

			String sql; // SQL문을 저장할 String
			sql = "SELECT * FROM CONTROL_TB";
			ResultSet rs = state.executeQuery(sql); // SQL문을 전달하여 실행

			while (rs.next()) {
				String controlKey = rs.getString("controlKey");
				String value1 = rs.getString("value1");
				String value2 = rs.getString("value2");
				System.out.println("KEY : " + controlKey + " Value1 : " + value1 + " Value2 : " + value2);
			}
			

			rs.close();
			state.close();
			conn.close();
		} catch (Exception e) {
			// 예외 발생 시 처리부분

		} finally { // 예외가 있든 없든 무조건 실행
			try {
				if (state != null)
					state.close();
			} catch (SQLException ex1) {
				//
			}

			try {
				if (conn != null)
					conn.close();
			} catch (SQLException ex1) {
				//
			}
		}
	}
}
