package ss;

public class ListB implements List {

	@Override
	public void put() {
		System.out.println("데이터 넣음 B");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void get() {
		System.out.println("데이터 얻음 B");
		// TODO Auto-generated method stub
		
	}
	
	public String getB() {
		System.out.println("GET B 실행");
		return "B";
	}
}
