package ss;

public class TestEE {

	public void aa(List a) {

		/*
		 * 전용 부분
		 * a가 ListA => getA를 실행한다
		 * a가 ListB => getB를 실행한다.
		 */
		if(a instanceof List) {
			a.get();
			a.put();
		}
		
		if(a instanceof ListA) {
			((ListA) a).getA();
		}
		
		
		// 공통부분
	}
	
	public void bb(ListA a) {
		
	}
	
	public void bb(ListB a) {
		
	}
	
}
