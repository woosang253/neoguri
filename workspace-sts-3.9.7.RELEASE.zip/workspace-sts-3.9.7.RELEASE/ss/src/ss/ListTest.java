package ss;

public class ListTest {

	public static void main(String[] args) {
		
		List a = new ListA();
		ListA aList = new ListA();
		
		
		List b = new ListB();
		ListB bList = new ListB();
		
		TestEE ee = new TestEE();
		ee.aa(a);
		ee.aa(b);
		ee.aa(aList);
		ee.aa(bList);
		
/**		
 * 		error
*/
//		ee.bb((ListA)a);
//		ee.bb((ListB)b);
		
			}
}
