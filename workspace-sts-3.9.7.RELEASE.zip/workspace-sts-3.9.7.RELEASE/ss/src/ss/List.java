package ss;

public interface List {

	void put();
	void get();
}
