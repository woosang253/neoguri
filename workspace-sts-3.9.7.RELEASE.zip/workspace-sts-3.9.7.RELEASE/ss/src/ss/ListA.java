package ss;

public class ListA implements List {

	@Override
	public void put() {
		System.out.println("데이터 넣음 A");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void get() {
		System.out.println("데이터 넣음 A");
		// TODO Auto-generated method stub
		
	}
	
	public String getA() {
		System.out.println("GET A 실행");
		return "A";
	}
}
